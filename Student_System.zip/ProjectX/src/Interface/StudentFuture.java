
package Interface;


public interface StudentFuture {
    
}
