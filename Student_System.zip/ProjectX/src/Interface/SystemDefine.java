
package Interface;


public interface SystemDefine {
    public static final int MAX_MEMBERS_COURSE = 30;
    public static final int MAX_REGIS_COURSE = 5;
}
