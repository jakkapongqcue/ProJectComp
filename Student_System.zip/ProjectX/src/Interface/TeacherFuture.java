
package Interface;


public interface TeacherFuture {
    
}
