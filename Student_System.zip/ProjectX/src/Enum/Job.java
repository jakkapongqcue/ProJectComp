
package Enum;


public enum Job {
    STUDENT, TEACHER
}
