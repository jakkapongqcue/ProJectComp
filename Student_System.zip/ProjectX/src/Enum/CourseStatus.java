
package Enum;


public enum CourseStatus {
    AVAILABLE, FULL, CLOSE
}
