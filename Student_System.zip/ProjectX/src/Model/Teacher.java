
package Model;

import Enum.Job;


public class Teacher extends Account{
    private String teachingCourse;
    private Job jobStatus;

    public Teacher(String id, Person person) {
        super(id, person);
        this.jobStatus = Job.TEACHER;
        
    }

    public String getTeachingCourse() {
        return teachingCourse;
    }

    public void setTeachingCourse(String teachingCourse) {
        this.teachingCourse = teachingCourse;
    }
    
    
}
