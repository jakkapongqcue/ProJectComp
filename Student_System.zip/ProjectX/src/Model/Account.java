
package Model;

import java.util.Objects;


public class Account {
    private String id;
    private Person person;

    public Account(String id, Person person) {
        this.id = id;
        this.person = person;
    }
    
    public String getId() {
        return id;
    }


    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Account other = (Account) obj;
        if (!Objects.equals(this.id, other.id)) {
            return false;
        }
        return true;
    }

    @Override
    public int hashCode() {
        int hash = 7;
        hash = 41 * hash + Objects.hashCode(this.id);
        return hash;
    }
    
    @Override
    public String toString() {
        return "Account{" + "id=" + id + ", person=" + person + '}';
    }
    
    
    
}
