
package Model;

import Enum.CourseStatus;
import java.util.Objects;


public class Course {
   private String courseName;
   private long idCourse;
   private CourseStatus status;

    public Course(String courseName, long idCourse) {
        this.courseName = courseName;
        this.idCourse = idCourse;
        this.status = CourseStatus.AVAILABLE;
    }

    public String getCourseName() {
        return courseName;
    }

    public long getIdCourse() {
        return idCourse;
    }

   

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Course other = (Course) obj;
        if (this.idCourse != other.idCourse) {
            return false;
        }
        return Objects.equals(this.courseName, other.courseName);
    }

    @Override
    public int hashCode() {
        int hash = 7;
        hash = 73 * hash + Objects.hashCode(this.courseName);
        hash = 73 * hash + (int) (this.idCourse ^ (this.idCourse >>> 32));
        return hash;
    }

    @Override
    public String toString() {
        return "Course{" + "courseName=" + courseName + ", idCourse=" + idCourse + '}';
    }
    
    
   
    
}
