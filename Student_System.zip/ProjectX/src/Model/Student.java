
package Model;

import Enum.Job;


public class Student extends Account{
    private double grade;
    private Job jobStatus;

    public Student(String id, Person person) {
        super(id, person);
        this.jobStatus = Job.STUDENT;
    }

    public double getGrade() {
        return grade;
    }

    public void setGrade(double grade) {
        this.grade = grade;
    }
    
    
    
}
