package Model;

public class Person {

    private final String name;
    private final String addess;
    private final String phone;

    public Person(String name, String addess, String phone) {
        this.name = name;
        this.addess = addess;
        this.phone = phone;
    }

    public String getName() {
        return name;
    }

    public String getAddess() {
        return addess;
    }

    public String getPhone() {
        return phone;
    }

    @Override
    public String toString() {
        return "Person{" + "name=" + name + ", addess=" + addess + ", phone=" + phone + '}';
    }

}
